CMPT 362 Mobile Programming
Group 21 WildTrace, a wildlife tracking app

APKs can be found in the youtube video descriptions.
